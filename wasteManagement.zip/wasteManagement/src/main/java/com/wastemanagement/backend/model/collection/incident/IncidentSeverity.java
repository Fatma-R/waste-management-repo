package com.wastemanagement.backend.model.collection.incident;

public enum IncidentSeverity {
    LOW, MEDIUM, HIGH, CRITICAL
}