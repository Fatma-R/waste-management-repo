package com.wastemanagement.backend.model.vehicle;

public enum VehicleStatus {
    AVAILABLE,
    IN_SERVICE,
    MAINTENANCE
}
