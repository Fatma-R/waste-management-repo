package com.wastemanagement.backend.dto.user;

import lombok.Data;

@Data
public class AdminResponseDTO {
    private String id;
    private String fullName;
    private String email;
}
