package com.wastemanagement.backend.dto.user;

import lombok.Data;

@Data
public class AdminRequestDTO {
    private String fullName;
    private String email;
}
