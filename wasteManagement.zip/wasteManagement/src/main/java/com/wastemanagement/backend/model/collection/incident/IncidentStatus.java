package com.wastemanagement.backend.model.collection.incident;

public enum IncidentStatus {
    OPEN,
    IN_PROGRESS,
    RESOLVED,
    CLOSED
}
