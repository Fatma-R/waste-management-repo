package com.wastemanagement.backend.model.user;

public enum ERole {
    ROLE_ADMIN,
    ROLE_USER
}
