package com.wastemanagement.backend.model.tournee;

public enum TourneeStatus {
    PLANNED,
    IN_PROGRESS,
    COMPLETED,
    CANCELED
}
