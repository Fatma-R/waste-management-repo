package com.wastemanagement.backend.model.user;

public enum Skill {
    DRIVER, AGENT
}