package com.wastemanagement.backend.model.collection;

public enum TrashType {
    GLASS, PLASTIC, ORGANIC, PAPER
}
