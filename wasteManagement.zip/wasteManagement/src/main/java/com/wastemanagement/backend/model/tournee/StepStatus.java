package com.wastemanagement.backend.model.tournee;

public enum StepStatus {
    PENDING,
    SERVICED,
    SKIPPED,
    BLOCKED
}
