package com.wastemanagement.backend.model.collection;

public enum AlertType {
    THRESHOLD,
    SENSOR_ANOMALY,
    BATTERY_LOW
}
